// 指導教授資料
export const PROFESSOR = {
  name: "王大明 教授",
  photo: "https://placehold.co/400x500",
  education: [
    "美國麻省理工學院 材料科學與工程博士",
    "國立台灣大學 材料科學與工程研究所碩士",
    "國立台灣大學 材料科學與工程學系學士"
  ],
  awards: [
    "2023 科技部傑出研究獎",
    "2022 材料學會會士",
    "2021 國際材料研究學會年度傑出貢獻獎",
    "2020 教育部教學卓越獎"
  ],
  researchInterests: [
    "超材料設計與製造",
    "奈米光電材料",
    "智慧感測元件",
    "生醫材料應用"
  ]
};

// 現任成員資料
export const CURRENT_MEMBERS = {
  researchAssistants: [
    {
      name: "李小明",
      photo: "https://placehold.co/300x400",
      title: "專任研究助理"
    }
  ],
  phdStudents: [
    {
      name: "張三",
      photo: "https://placehold.co/300x400",
      year: "博四"
    },
    {
      name: "李四",
      photo: "https://placehold.co/300x400",
      year: "博二"
    }
  ],
  masterStudents: [
    {
      name: "王五",
      photo: "https://placehold.co/300x400",
      year: "碩二"
    },
    {
      name: "趙六",
      photo: "https://placehold.co/300x400",
      year: "碩一"
    }
  ],
  undergraduates: [
    {
      name: "陳七",
      photo: "https://placehold.co/300x400",
      project: "超材料感測器設計"
    }
  ],
  apprentices: [
    {
      name: "林八",
      photo: "https://placehold.co/300x400",
      department: "材料系二年級"
    }
  ]
};

// 歷任成員資料
export const ALUMNI = [
  {
    name: "王九",
    graduationYear: 2023,
    degree: "博士",
    currentPosition: "台積電研發工程師"
  },
  {
    name: "張十",
    graduationYear: 2022,
    degree: "碩士",
    currentPosition: "聯電製程工程師"
  },
  {
    name: "李十一",
    graduationYear: 2021,
    degree: "碩士",
    currentPosition: "工研院研究員"
  }
]; 