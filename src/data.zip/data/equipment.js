export const EQUIPMENT_LIST = [
  {
    name: '掃描式電子顯微鏡 (SEM)',
    image: '/images/equipment/sem.jpg',
    purpose: '用於觀察材料表面形貌和微觀結構，可提供高解析度的表面形貌圖像。',
    features: [
      '高解析度成像能力',
      '可進行元素分析',
      '樣品製備簡單',
      '適用於導電和非導電樣品'
    ]
  },
  {
    name: 'X射線繞射儀 (XRD)',
    image: '/images/equipment/xrd.jpg',
    purpose: '用於分析材料的晶體結構、相組成和晶格參數等特性。',
    features: [
      '快速相鑑定',
      '非破壞性分析',
      '可進行定量分析',
      '晶體結構精修'
    ]
  },
  {
    name: '熱重分析儀 (TGA)',
    image: '/images/equipment/tga.jpg',
    purpose: '用於研究材料在加熱過程中的重量變化，分析材料的熱穩定性和成分。',
    features: [
      '精確的重量測量',
      '溫度控制精準',
      '可進行動力學分析',
      '氣氛控制功能'
    ]
  }
  // 可以根據實際設備繼續添加更多項目
]; 