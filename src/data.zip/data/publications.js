// 生成指定範圍內的隨機日期字符串
const getRandomDate = (start, end) => {
  const startDate = new Date(start).getTime();
  const endDate = new Date(end).getTime();
  const randomDate = new Date(startDate + Math.random() * (endDate - startDate));
  return randomDate.toISOString().split('T')[0];
};

export const MOCK_PUBLICATIONS = [
  {
    id: 1,
    title: "Novel Metamaterial Design for Enhanced Electromagnetic Wave Absorption",
    abstract: "本研究提出一種新型超材料結構設計，通過優化幾何結構和材料組合，實現了在特定頻率範圍內的高效電磁波吸收。實驗結果表明，該設計在 8-12 GHz 頻段具有超過 90% 的吸收率，且具有良好的角度穩定性。",
    authors: ["王大明", "李小華", "陳志明", "張美玲"],
    publishDate: "2023-12-15",
    journal: "Advanced Materials",
    tags: ["電磁波吸收", "超材料設計"],
    url: "https://doi.org/10.1002/adma.202312001"
  },
  {
    id: 2,
    title: "Acoustic Metamaterials for Noise Reduction in Urban Environments",
    abstract: "我們開發了一種新型聲學超材料，專門用於城市環境噪音控制。該材料採用特殊的周期性結構，能夠有效降低 100-1000 Hz 範圍內的噪音。實地測試顯示，在典型的城市環境中可實現平均 15dB 的噪音降低。",
    authors: ["李小華", "張美玲", "林建國"],
    publishDate: "2023-10-20",
    journal: "Applied Physics Letters",
    tags: ["聲學超材料", "噪音控制"],
    url: "https://doi.org/10.1063/apl.2023.10.020"
  },
  {
    id: 3,
    title: "Thermal Management in Electronic Devices Using Metamaterial Structures",
    abstract: "本研究探討了超材料結構在電子設備散熱管理中的應用。通過設計特殊的熱傳導通道，我們實現了比傳統散熱方案提高 45% 的散熱效率。這項技術特別適用於高功率密度的電子設備散熱需求。",
    authors: ["陳志明", "王大明", "黃雅琪"],
    publishDate: "2023-08-05",
    journal: "Nature Electronics",
    tags: ["熱管理", "電子散熱"],
    url: "https://doi.org/10.1038/s41928-023-0805-x"
  },
  {
    id: 4,
    title: "Metamaterial-Based Antennas for 5G Communication Systems",
    abstract: "本文提出了一種基於超材料的新型天線設計，適用於 5G 通信系統。該天線具有寬頻、高增益和小型化等特點，在 28GHz 和 39GHz 頻段都展現出優異的性能。實驗結果表明，天線增益比傳統設計提升了 30%。",
    authors: ["林建國", "王大明", "張美玲"],
    publishDate: "2023-11-30",
    journal: "IEEE Transactions on Antennas and Propagation",
    tags: ["5G通信", "天線設計", "超材料"],
    url: "https://doi.org/10.1109/TAP.2023.3334444"
  },
  {
    id: 5,
    title: "Optical Metamaterials for Enhanced Solar Energy Harvesting",
    abstract: "我們設計了一種新型光學超材料，可以顯著提高太陽能電池的光吸收效率。通過優化納米結構，實現了在可見光範圍內的寬頻吸收。測試結果顯示，太陽能電池的轉換效率提升了 20%。",
    authors: ["張美玲", "黃雅琪", "李小華"],
    publishDate: "2023-09-15",
    journal: "Nature Energy",
    tags: ["太陽能", "光學超材料"],
    url: "https://doi.org/10.1038/s41560-023-01234-5"
  },
  {
    id: 6,
    title: "Mechanical Metamaterials with Programmable Deformation Properties",
    abstract: "本研究開發了一種具有可編程形變特性的機械超材料。通過設計特殊的微觀結構，材料可以實現預設的形變行為。這種材料在軟體機器人和可重構結構中具有廣泛的應用前景。",
    authors: ["黃雅琪", "陳志明", "林建國"],
    publishDate: "2023-07-20",
    journal: "Advanced Functional Materials",
    tags: ["機械超材料", "可編程材料"],
    url: "https://doi.org/10.1002/adfm.202300000"
  },
  {
    id: 7,
    title: "Metamaterial-Enhanced Sensors for Environmental Monitoring",
    abstract: "我們提出了一種基於超材料的環境監測感測器設計。該感測器利用超材料的特殊電磁響應特性，可以實現對特定污染物的高靈敏度檢測。實驗證明，檢測靈敏度比傳統感測器提高了一個數量級。",
    authors: ["王大明", "張美玲", "李小華"],
    publishDate: "2023-06-10",
    journal: "Sensors and Actuators B: Chemical",
    tags: ["感測器", "環境監測"],
    url: "https://doi.org/10.1016/j.snb.2023.138888"
  },
  {
    id: 8,
    title: "Quantum Metamaterials: Theory and Applications",
    abstract: "本文系統性地研究了量子超材料的理論基礎和潛在應用。我們提出了一個新的理論框架，用於描述量子尺度下超材料的行為，並探討了其在量子計算和量子通信中的應用可能性。",
    authors: ["陳志明", "林建國", "黃雅琪"],
    publishDate: "2023-05-25",
    journal: "Physical Review Letters",
    tags: ["量子超材料", "理論研究"],
    url: "https://doi.org/10.1103/PhysRevLett.120.210501"
  },
  {
    id: 9,
    title: "Bio-inspired Metamaterial Designs for Medical Applications",
    abstract: "我們從生物結構中汲取靈感，設計了一系列用於醫療應用的超材料。這些材料具有優異的生物相容性和特定的物理特性，可用於組織工程和藥物遞送系統。",
    authors: ["李小華", "黃雅琪", "王大明"],
    publishDate: "2023-04-15",
    journal: "Nature Biomedical Engineering",
    tags: ["生物醫學", "仿生設計"],
    url: "https://doi.org/10.1038/s41551-023-00884-z"
  },
  {
    id: 10,
    title: "Metamaterial Absorbers for Terahertz Applications",
    abstract: "本研究開發了一種用於太赫茲頻段的超材料吸收體。通過精確控制材料的幾何結構，實現了在 0.5-2.5 THz 範圍內的高效吸收。這項技術在太赫茲成像和通信中具有重要應用價值。",
    authors: ["張美玲", "陳志明", "林建國"],
    publishDate: "2023-03-30",
    journal: "Optics Express",
    tags: ["太赫茲技術", "吸收體"],
    url: "https://doi.org/10.1364/OE.474345"
  },
  {
    id: 11,
    title: "Smart Windows Based on Electrochromic Metamaterials",
    abstract: "我們設計了一種基於電變色超材料的智能窗戶。這種窗戶可以通過電壓控制來調節其光學性質，實現對可見光和紅外線的動態調控。測試結果顯示，能源效率提升顯著。",
    authors: ["林建國", "李小華", "張美玲"],
    publishDate: "2023-02-20",
    journal: "Advanced Energy Materials",
    tags: ["智能窗戶", "節能技術"],
    url: "https://doi.org/10.1002/aenm.202300000"
  },
  {
    id: 12,
    title: "Metamaterial-based Acoustic Cloaking Devices",
    abstract: "本研究提出了一種新型聲學隱身裝置的設計方案。通過特殊的超材料結構，實現了對特定頻率聲波的有效繞射，使目標物體在聲學探測中難以被發現。",
    authors: ["黃雅琪", "王大明", "陳志明"],
    publishDate: "2023-01-15",
    journal: "Journal of Applied Physics",
    tags: ["聲學隱身", "波動控制"],
    url: "https://doi.org/10.1063/5.023456"
  },
  {
    id: 13,
    title: "Tunable Metamaterials for Wireless Communication",
    abstract: "我們開發了一種可調諧的通信用超材料。通過外部控制信號，可以動態調節材料的電磁響應特性，實現通信頻段的靈活切換和天線方向圖的實時調整。",
    authors: ["陳志明", "張美玲", "林建國"],
    publishDate: "2022-12-10",
    journal: "IEEE Transactions on Wireless Communications",
    tags: ["無線通信", "可調諧材料"],
    url: "https://doi.org/10.1109/TWC.2022.3204444"
  },
  {
    id: 14,
    title: "Metamaterial Solutions for EMI Shielding",
    abstract: "本文探討了超材料在電磁干擾屏蔽中的應用。我們設計的屏蔽材料具有優異的寬頻屏蔽效果，同時保持較薄的厚度和良好的柔韌性，適用於各種電子設備的電磁防護。",
    authors: ["王大明", "李小華", "黃雅琪"],
    publishDate: "2022-11-25",
    journal: "IEEE Transactions on Electromagnetic Compatibility",
    tags: ["電磁屏蔽", "防護技術"],
    url: "https://doi.org/10.1109/TEMC.2022.3204444"
  },
  {
    id: 15,
    title: "Self-healing Metamaterials for Sustainable Electronics",
    abstract: "我們開發了一種具有自修復能力的電子超材料。當材料受到物理損傷時，能夠通過內部機制自動修復，恢復原有的電學性能。這項技術對提高電子設備的使用壽命具有重要意義。",
    authors: ["張美玲", "林建國", "陳志明"],
    publishDate: "2022-10-20",
    journal: "Advanced Materials",
    tags: ["自修復材料", "可持續電子"],
    url: "https://doi.org/10.1002/adma.202200000"
  },
  {
    id: 16,
    title: "Metamaterial-based Quantum Light Sources",
    abstract: "本研究探討了利用超材料結構製備量子光源的新方法。通過精確控制納米腔的共振特性，實現了單光子源的高效率發射。這項技術在量子通信領域具有重要應用前景。",
    authors: ["李小華", "黃雅琪", "王大明"],
    publishDate: "2022-09-15",
    journal: "Nature Photonics",
    tags: ["量子光學", "光源技術"],
    url: "https://doi.org/10.1038/s41566-022-00884-z"
  },
  {
    id: 17,
    title: "Metamaterials for Enhanced MRI Imaging",
    abstract: "我們設計了一種用於提升磁共振成像質量的超材料。這種材料可以顯著增強局部磁場強度，提高成像解析度和信噪比。臨床測試顯示，圖像質量得到明顯改善。",
    authors: ["林建國", "陳志明", "張美玲"],
    publishDate: "2022-08-10",
    journal: "Nature Medicine",
    tags: ["醫學成像", "磁共振"],
    url: "https://doi.org/10.1038/s41591-022-01844-z"
  },
  {
    id: 18,
    title: "Plasmonic Metamaterials for Color Display",
    abstract: "本文提出了一種基於等離子體超材料的彩色顯示技術。通過控制納米結構的幾何參數，實現了高解析度、高飽和度的結構色顯示。這種技術具有低功耗、高耐久性等優點。",
    authors: ["黃雅琪", "王大明", "李小華"],
    publishDate: "2022-07-05",
    journal: "ACS Nano",
    tags: ["顯示技術", "結構色"],
    url: "https://doi.org/10.1021/acsnano.2c03000"
  },
  {
    id: 19,
    title: "Metamaterial Architectures for 3D Printing",
    abstract: "我們開發了一系列適用於 3D 打印的超材料結構設計。這些設計充分利用了增材製造的優勢，實現了複雜的力學性能和功能特性。實驗驗證了設計的可行性和性能的可重複性。",
    authors: ["陳志明", "張美玲", "林建國"],
    publishDate: "2022-06-20",
    journal: "Advanced Materials",
    tags: ["3D打印", "結構設計"],
    url: "https://doi.org/10.1002/adma.202200000"
  },
  {
    id: 20,
    title: "Metamaterial-Enhanced Photovoltaic Devices",
    abstract: "本研究探討了超材料在光伏器件中的應用。通過在太陽能電池中集成特殊設計的超材料結構，顯著提高了光的捕獲效率和電荷收集效率。實驗結果表明，器件效率提升了25%。",
    authors: ["王大明", "李小華", "黃雅琪"],
    publishDate: "2022-05-15",
    journal: "Nature Energy",
    tags: ["光伏技術", "能源轉換"],
    url: "https://doi.org/10.1038/s41560-022-00884-z"
  },
  {
    id: 21,
    title: "Adaptive Metamaterials for Space Applications",
    abstract: "我們設計了一種適用於太空環境的自適應超材料。該材料能夠根據環境溫度和輻射條件自動調節其物理特性，為航天器提供動態保護。實驗模擬驗證了其在極端條件下的可靠性。",
    authors: ["張美玲", "林建國", "陳志明"],
    publishDate: "2022-04-10",
    journal: "Advanced Space Research",
    tags: ["太空技術", "自適應材料"],
    url: "https://doi.org/10.1016/j.asr.2022.03.001"
  },
  {
    id: 22,
    title: "Metamaterial Waveguides for THz Communications",
    abstract: "本文提出了一種新型太赫茲波導設計。利用超材料的特殊色散特性，實現了低損耗、寬頻的太赫茲波傳輸。這項技術為未來的高速無線通信系統提供了重要支持。",
    authors: ["李小華", "黃雅琪", "王大明"],
    publishDate: "2022-03-05",
    journal: "Optics Express",
    tags: ["太赫茲通信", "波導技術"],
    url: "https://doi.org/10.1364/OE.474345"
  },
  {
    id: 23,
    title: "Metamaterial-based Acoustic Perfect Absorbers",
    abstract: "我們開發了一種完美聲學吸收體。通過精心設計的超材料結構，在特定頻率範圍內實現了接近100%的吸收率。這種材料在噪音控制和聲學工程中具有廣泛的應用前景。",
    authors: ["林建國", "陳志明", "張美玲"],
    publishDate: "2022-02-20",
    journal: "Applied Physics Letters",
    tags: ["聲學吸收", "噪音控制"],
    url: "https://doi.org/10.1063/5.023456"
  },
  {
    id: 24,
    title: "Quantum Metamaterials for Information Processing",
    abstract: "本研究探討了量子超材料在信息處理中的應用。我們提出了一種新的量子比特設計，利用超材料的量子相干特性，實現了更穩定的量子態操控。",
    authors: ["黃雅琪", "王大明", "李小華"],
    publishDate: "2022-01-15",
    journal: "Physical Review Letters",
    tags: ["量子計算", "信息處理"],
    url: "https://doi.org/10.1103/PhysRevLett.120.210501"
  },
  {
    id: 25,
    title: "Metamaterial Surfaces for Enhanced Heat Transfer",
    abstract: "我們設計了一種用於增強熱傳遞的超材料表面。通過優化微觀結構，顯著提高了對流換熱係數。這項技術在電子冷卻和工業換熱領域具有重要應用價值。",
    authors: ["陳志明", "張美玲", "林建國"],
    publishDate: "2021-12-10",
    journal: "International Journal of Heat and Mass Transfer",
    tags: ["熱傳遞", "表面設計"],
    url: "https://doi.org/10.1016/j.ijheatmasstransfer.2021.120456"
  },
  {
    id: 26,
    title: "Biocompatible Metamaterials for Drug Delivery",
    abstract: "本文提出了一種用於藥物遞送的生物相容性超材料。這種材料可以對特定生理信號響應，實現藥物的可控釋放。體外實驗證實了其良好的生物相容性和藥物釋放特性。",
    authors: ["王大明", "李小華", "黃雅琪"],
    publishDate: "2021-11-05",
    journal: "Advanced Healthcare Materials",
    tags: ["藥物遞送", "生物材料"],
    url: "https://doi.org/10.1002/adhm.202100000"
  },
  {
    id: 27,
    title: "Metamaterial Antennas for Satellite Communications",
    abstract: "我們開發了一種用於衛星通信的超材料天線。該天線具有高方向性和多頻段工作特性，同時體積小巧。實際測試表明，通信質量和可靠性都得到顯著提升。",
    authors: ["張美玲", "林建國", "陳志明"],
    publishDate: "2021-10-20",
    journal: "IEEE Transactions on Antennas and Propagation",
    tags: ["衛星通信", "天線設計"],
    url: "https://doi.org/10.1109/TAP.2021.3098444"
  },
  {
    id: 28,
    title: "Metamaterial-based Seismic Wave Control",
    abstract: "本研究探討了利用超材料進行地震波控制的可能性。通過大尺度周期性結構的設計，實現了特定頻率地震波的衰減和轉向。數值模擬和縮尺實驗驗證了理論預測。",
    authors: ["李小華", "黃雅琪", "王大明"],
    publishDate: "2021-09-15",
    journal: "Journal of Applied Physics",
    tags: ["地震工程", "波動控制"],
    url: "https://doi.org/10.1063/5.023456"
  },
  {
    id: 29,
    title: "Reconfigurable Metamaterials for Smart Buildings",
    abstract: "我們設計了一種用於智能建築的可重構超材料。該材料可以根據環境條件自動調節其光學和熱學性質，實現建築能耗的優化。長期測試顯示，能源效率提升顯著。",
    authors: ["林建國", "陳志明", "張美玲"],
    publishDate: "2021-08-10",
    journal: "Energy and Buildings",
    tags: ["智能建築", "節能技術"],
    url: "https://doi.org/10.1016/j.enbuild.2021.110456"
  },
  {
    id: 30,
    title: "Metamaterial-based Quantum Sensors",
    abstract: "本文提出了一種基於超材料的量子感測器設計。通過將量子探測器與超材料結構結合，實現了超高靈敏度的磁場和電場測量。這項技術在精密測量領域具有重要應用價值。",
    authors: ["黃雅琪", "王大明", "李小華"],
    publishDate: "2021-07-05",
    journal: "Nature Physics",
    tags: ["量子感測", "精密測量"],
    url: "https://doi.org/10.1038/s41567-021-01084-z"
  }
]; 

export const LATEST_PUBLICATIONS = MOCK_PUBLICATIONS.slice(0, 5);